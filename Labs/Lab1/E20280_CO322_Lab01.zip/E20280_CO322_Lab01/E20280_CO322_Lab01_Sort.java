
import java.util.Arrays;

/**
 * Simple sorting algorithms and their performance 
 * Reg: E/20/280
 *
 */

 public class E20280_CO322_Lab01_Sort {

    //create an array of given size and populate it with random data  
    static int [] create_rand_data(int size_of_array) {
	int [] data = new int[size_of_array];
	int i; 
	for(i=0; i < data.length; i++)
	    data[i] = (int)(Math.random() * 100);
	return data; 
    }

    //create an array of given size and populate it with worst data arrangement 
    static int [] create_worst_data(int size_of_array) {
	int [] data = new int[size_of_array];
	int i; 
	for(i=0; i < data.length; i++)
	    data[i] = data.length - i;
	return data; 
    }

    //create an array of given size and populate it with best data arrangement 
    static int [] create_best_data(int size_of_array) {
	int [] data = new int[size_of_array];
	int i; 
	for(i=0; i < data.length; i++)
	    data[i] = i;
	return data; 
    }

    // function to swap. Would be useful since all need this 
    static void swap(int []d, int i, int j) { 
	int tmp = d[i]; 
	d[i] = d[j]; 
	d[j] = tmp;
    }

    // check if the soring worked on the array 
    static boolean isSorted(int [] data) {
	int i;
	for(i=1; i < data.length; i++)
	    if(data[i] < data[i-1]) break;
	return (i == data.length);
    }

    // If you want just display the array as well :) 
    static void display(int []data) { 
		System.out.println("=======");
		for(int i=0; i < data.length; i++) 
			System.out.print(data[i] + "  "); 
		System.out.println("\n=======");
    }

    
    /**********************************************************
     *     Implementation of sorting algorithms               *
     *********************************************************/

    static void bubble_sort(int[] data) {
        int n = data.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (data[j] > data[j + 1]) {
                    swap(data, j, j + 1);
                }
            }
        }
    }

    static void bubble_sort_better1(int[] data) {
        int n = data.length;
        for (int i = n - 1; i > 0; i--) {
            for (int j = n - 1; j > n - i - 1; j--) {
                if (data[j] < data[j - 1]) {
                    // Swap if elements are in the wrong order
                    swap(data, j, j - 1);
                }
            }
        }
    }

    static void bubble_sort_better2(int[] data) {
        int n = data.length;
        boolean swapped; //  flag variable
    
        // Start from the end of the array and keep looping
        // until no swaps are made (array is sorted)
        int i = n - 1;
        while (i > 0) {
            swapped = false;  // Reset flag for each pass
    
            // first i elements are already sorted
            int j = n - 1;
            while (j > n - i - 1) {
                if (data[j] < data[j - 1]) {
                    swap(data, j, j - 1);
                    swapped = true;  // A swap has been made flag
                }
                j--;
            }
            // if no swaps were made,the array is sorted and we can brake early    
            if (!swapped) { 
                break;
            }
            i--;
        }
    }
    
    static void selection_sort(int[] data) {
        int n = data.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (data[j] < data[minIndex]) {
                    minIndex = j;
                }
            }
            swap(data, i, minIndex);
        }
    }

    static void insertion_sort(int[] data) {
        int n = data.length;
        for (int i = 1; i < n; i++) {
            int key = data[i];
            int j = i - 1;
            while (j >= 0 && data[j] > key) {
                data[j + 1] = data[j];
                j--;
            }
            data[j + 1] = key;
        }
    }
    public static void main(String[] args) {
        // Step sizes from 100 to 1500
        int[] stepSizes = {1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 11000, 12000, 13000, 14000, 15000};

        // Measure and display execution times for each step size and algorithm
        for (int stepSize : stepSizes) {
            int[] bestData = create_best_data(stepSize);
            int[] randData = create_rand_data(stepSize);
            int[] worstData = create_worst_data(stepSize);

            System.out.println("\nStep size: " + stepSize);

            // Best Data
            System.out.println("Best Data");
            measureAndDisplayTime(bestData, "Bubble Sort", E20280_CO322_Lab01_Sort::bubble_sort);
            measureAndDisplayTime(bestData, "Bubble Sort Better1", E20280_CO322_Lab01_Sort::bubble_sort_better1);
            measureAndDisplayTime(bestData, "Bubble Sort Better2", E20280_CO322_Lab01_Sort::bubble_sort_better2);
            measureAndDisplayTime(bestData, "Selection Sort", E20280_CO322_Lab01_Sort::selection_sort);
            measureAndDisplayTime(bestData, "Insertion Sort", E20280_CO322_Lab01_Sort::insertion_sort);
            System.out.println();

            // Random Data
            System.out.println("Random Data");
            measureAndDisplayTime(randData, "Bubble Sort", E20280_CO322_Lab01_Sort::bubble_sort);
            measureAndDisplayTime(randData, "Bubble Sort Better1", E20280_CO322_Lab01_Sort::bubble_sort_better1);
            measureAndDisplayTime(randData, "Bubble Sort Better2", E20280_CO322_Lab01_Sort::bubble_sort_better2);
            measureAndDisplayTime(randData, "Selection Sort", E20280_CO322_Lab01_Sort::selection_sort);
            measureAndDisplayTime(randData, "Insertion Sort", E20280_CO322_Lab01_Sort::insertion_sort);
            System.out.println();


            // Worst Data
            System.out.println("Worst Data");
            measureAndDisplayTime(worstData, "Bubble Sort", E20280_CO322_Lab01_Sort::bubble_sort);
            measureAndDisplayTime(worstData, "Bubble Sort Better1", E20280_CO322_Lab01_Sort::bubble_sort_better1);
            measureAndDisplayTime(worstData, "Bubble Sort Better2", E20280_CO322_Lab01_Sort::bubble_sort_better2);
            measureAndDisplayTime(worstData, "Selection Sort", E20280_CO322_Lab01_Sort::selection_sort);
            measureAndDisplayTime(worstData, "Insertion Sort", E20280_CO322_Lab01_Sort::insertion_sort);
            System.out.println();

        }
    }

    @FunctionalInterface
    interface SortAlgorithm {
        void sort(int[] data);
    }

    static void measureAndDisplayTime(int[] originalData, String algorithmName, SortAlgorithm algorithm) {
        int[] data = Arrays.copyOf(originalData, originalData.length);
        long startTime = System.nanoTime();
        algorithm.sort(data);
        long endTime = System.nanoTime();

        long executionTime = endTime - startTime;

        // Display the execution time for this sorting algorithm and data
        System.out.println(algorithmName + " Execution Time: " + executionTime + " nanoseconds");

        if (isSorted(data)) {
            System.out.println("Sorted!!!");
        } else {
            System.out.println("Not Sorted!");
        }
    }
}